package com.assignment.EmployeeManagementSystem;

import com.assignment.EmployeeManagementSystem.entity.Employee;
import com.assignment.EmployeeManagementSystem.repository.EmployeeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY) // Use an in-memory database
@Transactional
public class EmployeeRepositoryTests {

    @Autowired
    private EmployeeRepository employeeRepository;

    @BeforeEach
    void setUp() {
        employeeRepository.deleteAll(); // Ensure a clean slate for each test
    }

    @Test
    void testSaveEmployee() {
        Employee employee = new Employee();
        employee.setName("John Doe");
        employee.setEmail("john.doe@example.com");

        Employee savedEmployee = employeeRepository.save(employee);

        assertThat(savedEmployee).isNotNull();
        assertThat(savedEmployee.getId()).isNotNull();
        assertThat(savedEmployee.getName()).isEqualTo("John Doe");
    }

    @Test
    void testFindByEmail() {
        Employee employee = new Employee();
        employee.setName("Jane Doe");
        employee.setEmail("jane.doe@example.com");
        employeeRepository.save(employee);

        Employee foundEmployee = employeeRepository.findByEmail("jane.doe@example.com");

        assertThat(foundEmployee).isNotNull();
        assertThat(foundEmployee.getName()).isEqualTo("Jane Doe");
    }
}
