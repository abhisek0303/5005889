package com.assignment.EmployeeManagementSystem;

import com.assignment.EmployeeManagementSystem.entity.Employee;
import com.assignment.EmployeeManagementSystem.repository.EmployeeRepository;
import com.assignment.EmployeeManagementSystem.service.EmployeeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.when;

public class EmployeeServiceTests {

    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private EmployeeService employeeService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFindEmployeeById() {
        Employee employee = new Employee();
        employee.setId(1L);
        employee.setName("John Doe");

        given(employeeRepository.findById(1L)).willReturn(Optional.of(employee));

        Employee foundEmployee = employeeService.findById(1L);

        assertThat(foundEmployee).isNotNull();
        assertThat(foundEmployee.getName()).isEqualTo("John Doe");
    }
}
